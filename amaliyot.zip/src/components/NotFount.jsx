import React from "react";

export default function NotFount(props) {
  return (
    <div className="notfound">
      <div className="container text-center my-4">
        <h2>
          <b>404</b>
        </h2>
        <h1>Page NotFount</h1>
      </div>
    </div>
  );
}
