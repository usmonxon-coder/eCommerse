import { loading } from "../reducers/loading";

export const globalTypes = {
  AUTH: "AUTH",
  LOADING: "LOADING",
  LANG: "LANG",
  PRODUCTS: "PRODUCTS",
  ADD_TO_CART: "ADD_TO_CART",
  CATEGORY: "CATEGORY",
  PAGE: "PAGE",
  INCREMENT: "INCREMENT",
  DICRIMENT: "DICRIMENT",
};
