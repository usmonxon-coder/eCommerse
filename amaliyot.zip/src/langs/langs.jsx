import { engContent } from "./eng";
import { uzContent } from "./uz";

export const langs = {
  Uz: uzContent,
  Eng: engContent,
};
